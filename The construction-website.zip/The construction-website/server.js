
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));

// Connect to MongoDB

const mongoURI = process.env.MONGO_URI;
mongoose.connect('mongodb://localhost:27017/construction')
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Error connecting to MongoDB: ', err));

// Define user schema and model
const userSchema = new mongoose.Schema({
  email: String,
  password: String

 
});
const User = mongoose.model('User', userSchema);

// Routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Registration route
app.post('/register', (req, res) => {
  const { email, password } = req.body;

  // Create a new user instance
  const newUser = new User({ email: 'user@example.com', password: 'password123' });

newUser.save()
  .then(() => {
    // If the user is successfully registered, send a response
    res.send('User registered successfully!');
  })
  .catch((error) => {
    // If there's an error during saving, send an error response
    console.error('Error saving user data:', error);
    res.status(500).send('Internal Server Error');
  });

});

// Assuming Userdata is the mongoose model for storing user data

// app.post('/store', (req, res) => {
//   // Extracting 'add' and 'pas' from the request body using object destructuring
//   var { email, password } = req.body;

//   // Check if the email already exists in the database
//   User.findOne({email })
//     .then((existingUser) => {
//       if (existingUser === null) {
//         // If the email doesn't exist, create a new user record
//         var newUser = new User({
//           email: req.body.email,
//           password: req.body.password
//           // Other fields like Name, Username, etc. can be added here
//         });

 


//         // Save the new user record to the database
//         newUser.save()
//           .then(() => {
//             // If the user is successfully registered, send a response
//             res.sendFile(path.join(__dirname, "index.html"));
//           })
//           .catch((error) => {
//             // If there's an error during saving, send an error response
//             console.error('Error saving user data:', error);
//             res.status(500).send('<h1>Internal Server Error</h1>');
//           });
//       } else {
//         // If the email already exists, send a response indicating the duplication
//         res.send('<h1>Such email is already in use. Please choose a different email.</h1>');
//       }
//     })
//     .catch((error) => {
//       // If there's an error during database query, send an error response
//       console.error('Error querying user data:', error);
//       res.status(500).send('<h1>Internal Server Error</h1>');
//     });
// });


// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
